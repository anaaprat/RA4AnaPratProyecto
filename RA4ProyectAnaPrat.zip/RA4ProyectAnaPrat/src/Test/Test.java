package Test;

import views.IniPage;

public class Test {

	public static void main(String[] args) {
		new IniPage().setVisible(true);
	}

}
